import { db } from './firebase';
import { 
  collection, 
  getDocs, 
  doc, 
  setDoc, 
  writeBatch
} from 'firebase/firestore';
import { obtenerAsesorias } from './asesoriaService';
import { getAnuncios } from './anunciosService';
import { getUsuarios } from './firestoreServices'; 

// ========== OBTENER TODOS LOS DATOS ==========
export const obtenerTodosLosDatos = async () => {
  try {
    const [anuncios, asesorias, usuarios] = await Promise.all([
      getAnuncios(),
      obtenerAsesorias(),
      getUsuarios().catch(() => [])
    ]);

    return {
      anuncios: anuncios || [],
      asesorias: asesorias || [],
      usuarios: usuarios || [],
      fechaRespaldo: new Date().toLocaleString(),
      timestamp: Date.now(),
      version: '1.0'
    };
  } catch (error) {
    console.error("Error al obtener datos:", error);
    throw error;
  }
};

// ========== RESPALDO COMPLETO ==========
export const crearRespaldoCompleto = async () => {
  try {
    const datos = await obtenerTodosLosDatos();
    
    localStorage.setItem('backup_completo', JSON.stringify(datos, null, 2));
    
    const blob = new Blob(
      [JSON.stringify(datos, null, 2)],
      { type: "application/json" }
    );
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `backup_completo_${new Date().toISOString().slice(0,19)}.json`;
    a.click();
    
    URL.revokeObjectURL(url);
    
    return { success: true, mensaje: "Respaldo completado exitosamente" };
  } catch (error) {
    console.error("Error al crear respaldo:", error);
    return { success: false, mensaje: error.message };
  }
};

// ========== RESPALDO SOLO DE ASESORÍAS ==========
export const descargarBackupAsesorias = async () => {
  try {
    const asesorias = await obtenerAsesorias();
    
    const datos = {
      asesorias: asesorias,
      fechaRespaldo: new Date().toLocaleString(),
      timestamp: Date.now(),
      tipo: "asesorias"
    };
    
    const blob = new Blob(
      [JSON.stringify(datos, null, 2)],
      { type: "application/json" }
    );
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `backup_asesorias_${new Date().toISOString().slice(0,19)}.json`;
    a.click();
    
    URL.revokeObjectURL(url);
    
    return { success: true, mensaje: "Respaldo de asesorías completado" };
  } catch (error) {
    console.error("Error al respaldar asesorías:", error);
    return { success: false, mensaje: error.message };
  }
};

// ========== RESPALDO SOLO DE ANUNCIOS ==========
export const descargarBackupAnuncios = async () => {
  try {
    const anuncios = await getAnuncios();
    
    const datos = {
      anuncios: anuncios,
      fechaRespaldo: new Date().toLocaleString(),
      timestamp: Date.now(),
      tipo: "anuncios"
    };
    
    const blob = new Blob(
      [JSON.stringify(datos, null, 2)],
      { type: "application/json" }
    );
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `backup_anuncios_${new Date().toISOString().slice(0,19)}.json`;
    a.click();
    
    URL.revokeObjectURL(url);
    
    return { success: true, mensaje: "Respaldo de anuncios completado" };
  } catch (error) {
    console.error("Error al respaldar anuncios:", error);
    return { success: false, mensaje: error.message };
  }
};

// ========== RECUPERAR DATOS DESDE ARCHIVO ==========
export const recuperarDatos = async (archivoJSON) => {
  try {
    const datos = JSON.parse(archivoJSON);
    
    if (!datos || (!datos.anuncios && !datos.asesorias && !datos.usuarios)) {
      throw new Error('Archivo de respaldo inválido o vacío');
    }
    
    const resultados = {
      anuncios: 0,
      asesorias: 0,
      usuarios: 0,
      errores: []
    };
    
    // Recuperar anuncios
    if (datos.anuncios && datos.anuncios.length > 0) {
      try {
        const batch = writeBatch(db);
        for (const anuncio of datos.anuncios) {
          const docRef = doc(db, "anuncios", anuncio.id);
          batch.set(docRef, anuncio);
          resultados.anuncios++;
        }
        await batch.commit();
      } catch (error) {
        resultados.errores.push(`Anuncios: ${error.message}`);
      }
    }
    
    // Recuperar asesorías
    if (datos.asesorias && datos.asesorias.length > 0) {
      try {
        const batch = writeBatch(db);
        for (const asesoria of datos.asesorias) {
          const docRef = doc(db, "asesorias", asesoria.id);
          batch.set(docRef, asesoria);
          resultados.asesorias++;
        }
        await batch.commit();
      } catch (error) {
        resultados.errores.push(`Asesorías: ${error.message}`);
      }
    }
    
    // Recuperar usuarios
    if (datos.usuarios && datos.usuarios.length > 0) {
      try {
        const batch = writeBatch(db);
        for (const usuario of datos.usuarios) {
          const docRef = doc(db, "usuarios", usuario.id);
          batch.set(docRef, usuario);
          resultados.usuarios++;
        }
        await batch.commit();
      } catch (error) {
        resultados.errores.push(`Usuarios: ${error.message}`);
      }
    }
    
    const mensaje = `Recuperación completada: ${resultados.anuncios} anuncios, ${resultados.asesorias} asesorías, ${resultados.usuarios} usuarios restaurados.`;
    
    return { 
      success: true, 
      mensaje: mensaje,
      detalles: resultados
    };
    
  } catch (error) {
    console.error("Error al recuperar datos:", error);
    return { success: false, mensaje: error.message };
  }
};

// ========== LISTAR RESPALDOS GUARDADOS ==========
export const listarRespaldosLocales = () => {
  const respaldos = [];
  
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && (key.includes('backup'))) {
      try {
        const data = JSON.parse(localStorage.getItem(key));
        respaldos.push({
          key: key,
          fecha: data.fechaRespaldo || data.fecha,
          timestamp: data.timestamp,
          tipo: data.tipo || 'completo'
        });
      } catch (e) {}
    }
  }
  
  return respaldos.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
};