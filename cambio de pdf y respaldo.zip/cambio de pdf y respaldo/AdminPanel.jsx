import React, { useState } from 'react';
import { 
  crearRespaldoCompleto, 
  descargarBackupAsesorias, 
  descargarBackupAnuncios,
  listarRespaldosLocales,
  recuperarDatos
} from '../services/backupService';

const AdminPanel = ({ usuario, datos }) => {
  const [loading, setLoading] = useState(false);
  const [mensaje, setMensaje] = useState({ texto: '', tipo: '' });
  const [respaldos, setRespaldos] = useState(listarRespaldosLocales());

  // Verificar que sea Administrador
  if (datos?.Rol !== 'Admin') {
    return (
      <div className="container py-5">
        <div className="alert alert-danger text-center">
          <i className="bi bi-shield-lock-fill fs-1"></i>
          <h3 className="mt-3">Acceso Denegado</h3>
          <p>No tienes permisos para acceder a esta página.</p>
        </div>
      </div>
    );
  }

  const handleRespaldoCompleto = async () => {
    setLoading(true);
    const resultado = await crearRespaldoCompleto();
    setMensaje({ texto: resultado.mensaje, tipo: resultado.success ? 'success' : 'danger' });
    setRespaldos(listarRespaldosLocales());
    setLoading(false);
  };

  const handleRespaldoAsesorias = async () => {
    setLoading(true);
    const resultado = await descargarBackupAsesorias();
    setMensaje({ texto: resultado.mensaje, tipo: resultado.success ? 'success' : 'danger' });
    setLoading(false);
  };

  const handleRespaldoAnuncios = async () => {
    setLoading(true);
    const resultado = await descargarBackupAnuncios();
    setMensaje({ texto: resultado.mensaje, tipo: resultado.success ? 'success' : 'danger' });
    setLoading(false);
  };

  const handleRecuperar = async (event) => {
    const archivo = event.target.files[0];
    if (!archivo) return;
    
    setLoading(true);
    const reader = new FileReader();
    
    reader.onload = async (e) => {
      const resultado = await recuperarDatos(e.target.result);
      setMensaje({ texto: resultado.mensaje, tipo: resultado.success ? 'success' : 'danger' });
      setLoading(false);
    };
    
    reader.readAsText(archivo);
  };

  return (
    <div className="container py-4">
      <div className="row">
        <div className="col-lg-10 mx-auto">
          
          {/* Header */}
          <div className="card shadow-sm border-0 mb-4">
            <div className="card-body">
              <h2 className="fw-bold mb-1">
                <i className="bi bi-shield-lock-fill text-success me-2"></i>
                Panel de Administración
              </h2>
              <p className="text-muted">
                Gestión de respaldos y recuperación de la base de datos
              </p>
            </div>
          </div>

          {/* Mensaje */}
          {mensaje.texto && (
            <div className={`alert alert-${mensaje.tipo} alert-dismissible fade show`} role="alert">
              <i className={`bi bi-${mensaje.tipo === 'success' ? 'check-circle' : 'exclamation-triangle'} me-2`}></i>
              {mensaje.texto}
              <button type="button" className="btn-close" onClick={() => setMensaje({ texto: '', tipo: '' })}></button>
            </div>
          )}

          {/* Respaldo Completo */}
          <div className="card shadow-sm border-0 mb-4">
            <div className="card-body">
              <h5 className="fw-bold mb-3">
                <i className="bi bi-database-fill-down text-success me-2"></i>
                Respaldo Completo
              </h5>
              <p className="text-muted mb-3">
                Crea un respaldo de TODAS las colecciones (anuncios, asesorías, usuarios).
              </p>
              <button 
                className="btn btn-success px-4"
                onClick={handleRespaldoCompleto}
                disabled={loading}
              >
                {loading ? (
                  <span className="spinner-border spinner-border-sm me-2"></span>
                ) : (
                  <i className="bi bi-cloud-arrow-down-fill me-2"></i>
                )}
                Respaldo Completo
              </button>
            </div>
          </div>

          {/* Respaldos Específicos */}
          <div className="row g-4 mb-4">
            <div className="col-md-6">
              <div className="card shadow-sm border-0 h-100">
                <div className="card-body">
                  <h5 className="fw-bold mb-3">
                    <i className="bi bi-megaphone-fill text-info me-2"></i>
                    Respaldo de Anuncios
                  </h5>
                  <p className="text-muted mb-3">Respaldar solo la colección de anuncios.</p>
                  <button 
                    className="btn btn-outline-primary"
                    onClick={handleRespaldoAnuncios}
                    disabled={loading}
                  >
                    <i className="bi bi-file-text me-2"></i>
                    Respaldar Anuncios
                  </button>
                </div>
              </div>
            </div>
            
            <div className="col-md-6">
              <div className="card shadow-sm border-0 h-100">
                <div className="card-body">
                  <h5 className="fw-bold mb-3">
                    <i className="bi bi-calendar-check-fill text-warning me-2"></i>
                    Respaldo de Asesorías
                  </h5>
                  <p className="text-muted mb-3">Respaldar solo la colección de asesorías.</p>
                  <button 
                    className="btn btn-outline-warning"
                    onClick={handleRespaldoAsesorias}
                    disabled={loading}
                  >
                    <i className="bi bi-file-text me-2"></i>
                    Respaldar Asesorías
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Recuperación */}
          <div className="card shadow-sm border-0 mb-4">
            <div className="card-body">
              <h5 className="fw-bold mb-3">
                <i className="bi bi-database-fill-up text-danger me-2"></i>
                Recuperar Base de Datos
              </h5>
              <p className="text-muted mb-3">
                Selecciona un archivo de respaldo (.json) para restaurar los datos.
                <strong className="text-danger d-block mt-2">
                  ⚠️ Advertencia: Esta acción sobrescribirá los datos actuales.
                </strong>
              </p>
              <input 
                type="file" 
                accept=".json"
                className="form-control mb-3"
                onChange={handleRecuperar}
                disabled={loading}
                style={{ maxWidth: '300px' }}
              />
            </div>
          </div>

          {/* Historial */}
          {respaldos.length > 0 && (
            <div className="card shadow-sm border-0">
              <div className="card-body">
                <h5 className="fw-bold mb-3">
                  <i className="bi bi-clock-history text-secondary me-2"></i>
                  Respaldos Guardados
                </h5>
                <div className="table-responsive">
                  <table className="table table-sm">
                    <thead>
                      <tr>
                        <th>Fecha</th>
                        <th>Tipo</th>
                        <th>Archivo</th>
                      </tr>
                    </thead>
                    <tbody>
                      {respaldos.map((backup, index) => (
                        <tr key={index}>
                          <td>{backup.fecha}</td>
                          <td>
                            <span className={`badge bg-${backup.tipo === 'completo' ? 'success' : 'info'}`}>
                              {backup.tipo}
                            </span>
                          </td>
                          <td><code className="small">{backup.key}</code></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

export default AdminPanel;