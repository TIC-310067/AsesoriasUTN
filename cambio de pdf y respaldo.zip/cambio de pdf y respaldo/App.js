import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import "bootstrap/dist/js/bootstrap.bundle.min.js";

import Navbar from "./routes/Navbar";
import AppRouter from "./routes/AppRouter";

import { useContext, useEffect, useState } from "react";
import { AuthContext } from "./context/authContext.js";

// SERVICE
import { getUserData } from "./services/userService";

function App() {

  // Usuario global (Auth)
  const { usuario } = useContext(AuthContext);

  // Estado para datos de Firestore
  const [datos, setDatos] = useState(null);
  const [loading, setLoading] = useState(true);

  // Traer datos cuando haya usuario
  useEffect(() => {
    const cargarDatos = async () => {
      if (usuario) {
        const data = await getUserData(usuario.uid);
        setDatos(data);
      } else {
        setDatos(null);
      }
      setLoading(false);
    };

    cargarDatos();
  }, [usuario]);

  // Mostrar loading mientras se cargan datos
  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center vh-100">
        <div className="spinner-border text-success" role="status">
          <span className="visually-hidden">Cargando...</span>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* 🔥 NAVBAR GLOBAL - Solo visible cuando hay usuario */}
      {usuario && <Navbar usuario={usuario} datos={datos} />}

      {/* 🔥 CONTENIDO PRINCIPAL - Usar AppRouter para manejar rutas */}
      <main style={{ marginTop: usuario ? "50px" : "0" }}>
        <AppRouter usuario={usuario} datos={datos} />
      </main>
    </>
  );
}

export default App;