import { generarReporteAsesoriasPDF, generarReporteAnunciosPDF, generarReporteUsuariosPDF, generarReporteCompletoPDF } from './pdf';

export {
  generarReporteAsesoriasPDF,
  generarReporteAnunciosPDF,
  generarReporteUsuariosPDF,
  generarReporteCompletoPDF
};