// src/views/Reportes.jsx
import React, { useState } from 'react';
import { 
  generarReporteAsesoriasPDF,
  generarReporteAnunciosPDF,
  generarReporteUsuariosPDF,
  generarReporteCompletoPDF
} from '../services/reportesService';

const Reportes = ({ usuario, datos }) => {
  const [loading, setLoading] = useState(false);
  const [mensaje, setMensaje] = useState({ texto: '', tipo: '' });

  const handleReporte = async (tipo) => {
    setLoading(true);
    setMensaje({ texto: '', tipo: '' });
    
    let resultado;
    
    switch (tipo) {
      case 'asesorias':
        resultado = await generarReporteAsesoriasPDF();
        break;
      case 'anuncios':
        resultado = await generarReporteAnunciosPDF();
        break;
      case 'usuarios':
        if (datos?.Rol === "Admin") {
          resultado = await generarReporteUsuariosPDF();
        } else {
          resultado = { success: false, mensaje: "No tienes permisos para este reporte" };
        }
        break;
      case 'completo':
        if (datos?.Rol === "Admin") {
          resultado = await generarReporteCompletoPDF();
        } else {
          resultado = { success: false, mensaje: "No tienes permisos para este reporte" };
        }
        break;
      default:
        resultado = { success: false, mensaje: 'Opción no válida' };
    }
    
    setMensaje({ 
      texto: resultado.mensaje, 
      tipo: resultado.success ? 'success' : 'danger' 
    });
    
    setLoading(false);
    setTimeout(() => setMensaje({ texto: '', tipo: '' }), 3000);
  };

  return (
    <div className="container py-4">
      <div className="row">
        <div className="col-lg-10 mx-auto">
          
          <div className="card shadow-sm border-0 mb-4">
            <div className="card-body">
              <h2 className="fw-bold mb-1">
                <i className="bi bi-file-pdf-fill text-danger me-2"></i>
                Generador de Reportes
              </h2>
              <p className="text-muted">
                Selecciona el tipo de reporte que deseas generar en formato PDF
              </p>
            </div>
          </div>

          {mensaje.texto && (
            <div className={`alert alert-${mensaje.tipo} alert-dismissible fade show mb-4`}>
              <i className={`bi bi-${mensaje.tipo === 'success' ? 'check-circle' : 'exclamation-triangle'} me-2`}></i>
              {mensaje.texto}
              <button type="button" className="btn-close" onClick={() => setMensaje({ texto: '', tipo: '' })}></button>
            </div>
          )}

          <div className="row g-4">
            {/* Reporte de Asesorías */}
            <div className="col-md-6">
              <div className="card shadow-sm border-0 h-100">
                <div className="card-body">
                  <h5 className="fw-bold mb-3">
                    <i className="bi bi-calendar-check-fill text-warning me-2"></i>
                    Reporte de Asesorías
                  </h5>
                  <p className="text-muted">Genera un reporte con el registro completo de asesorías.</p>
                  <button 
                    className="btn btn-outline-warning"
                    onClick={() => handleReporte('asesorias')}
                    disabled={loading}
                  >
                    {loading ? <span className="spinner-border spinner-border-sm me-2"></span> : <i className="bi bi-file-pdf me-2"></i>}
                    Generar PDF
                  </button>
                </div>
              </div>
            </div>
            
            {/* Reporte de Anuncios */}
            <div className="col-md-6">
              <div className="card shadow-sm border-0 h-100">
                <div className="card-body">
                  <h5 className="fw-bold mb-3">
                    <i className="bi bi-megaphone-fill text-success me-2"></i>
                    Reporte de Anuncios
                  </h5>
                  <p className="text-muted">Genera un reporte con todos los anuncios del tablón.</p>
                  <button 
                    className="btn btn-outline-success"
                    onClick={() => handleReporte('anuncios')}
                    disabled={loading}
                  >
                    {loading ? <span className="spinner-border spinner-border-sm me-2"></span> : <i className="bi bi-file-pdf me-2"></i>}
                    Generar PDF
                  </button>
                </div>
              </div>
            </div>

            {/* Reporte de Usuarios (Solo Admin) */}
            {datos?.Rol === "Admin" && (
              <div className="col-md-6">
                <div className="card shadow-sm border-0 h-100">
                  <div className="card-body">
                    <h5 className="fw-bold mb-3">
                      <i className="bi bi-people-fill text-primary me-2"></i>
                      Reporte de Usuarios
                    </h5>
                    <p className="text-muted">Genera un reporte con todos los usuarios del sistema.</p>
                    <button 
                      className="btn btn-outline-primary"
                      onClick={() => handleReporte('usuarios')}
                      disabled={loading}
                    >
                      {loading ? <span className="spinner-border spinner-border-sm me-2"></span> : <i className="bi bi-file-pdf me-2"></i>}
                      Generar PDF
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Reporte Completo (Solo Admin) */}
            {datos?.Rol === "Admin" && (
              <div className="col-md-6">
                <div className="card shadow-sm border-0 h-100">
                  <div className="card-body">
                    <h5 className="fw-bold mb-3">
                      <i className="bi bi-database-fill text-secondary me-2"></i>
                      Reporte Completo
                    </h5>
                    <p className="text-muted">Genera un reporte con TODA la información del sistema.</p>
                    <button 
                      className="btn btn-outline-secondary"
                      onClick={() => handleReporte('completo')}
                      disabled={loading}
                    >
                      {loading ? <span className="spinner-border spinner-border-sm me-2"></span> : <i className="bi bi-file-pdf me-2"></i>}
                      Generar PDF
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reportes;